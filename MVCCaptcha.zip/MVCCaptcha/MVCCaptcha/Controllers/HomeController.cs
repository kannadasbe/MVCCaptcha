﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCCaptcha.Models;
using CaptchaMvc.HtmlHelpers;
using System.Drawing;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace MVCCaptcha.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        /// Mathematical Captcha example
        /// </summary>
        /// <param name="length"></param>
        /// <param name="noisy"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult TestMathCaptcha()
        {
            ViewBag.Message = "Test Math Captcha";
            return View();
        }

        [HttpPost]
        public ActionResult TestMathCaptcha(Employee employee)
        {
            if (Session["MathCaptcha"] == null || Session["MathCaptcha"].ToString() != employee.Captcha)
            {
                ModelState.AddModelError("Captcha", "Wrong value of sum, please try again.");
                //dispay error and generate a new captcha 
                return View(employee);
            }
            return RedirectToAction("ThankYou");
        }

        /// <summary>
        /// Text captcha example
        /// </summary>
        /// <param name="length"></param>
        /// <param name="noisy"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult TestTextCaptcha()
        {
            ViewBag.Message = "Test Text Captcha";
            return View();
        }

        [HttpPost]
        public ActionResult TestTextCaptcha(Employee employee)
        {
            if (Session["TextCaptcha"] == null || Session["TextCaptcha"].ToString() != employee.Captcha)
            {
                ModelState.AddModelError("Captcha", "Wrong text entered, please try again.");
                //dispay error and generate a new captcha 
                return View(employee);
            }
            return RedirectToAction("ThankYou");
        }

        public ActionResult ThankYou()
        {
            ViewBag.Message = "Thank you.";

            return View();
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        /// <summary>
        /// Mathematical Captcha example
        /// </summary>
        /// <param name="length"></param>
        /// <param name="noisy"></param>
        /// <returns></returns>
        public ActionResult MathematicalCaptcha(bool noisy = true)
        {
            var random = new Random((int)DateTime.Now.Ticks);

            var captcha = "";

            //generate new question 
            int a = random.Next(10, 99);
            int b = random.Next(0, 9);
            captcha = string.Format("{0} + {1} = ?", a, b);
            //store answer 
            Session["MathCaptcha"] = a + b;
            return RenderImage(captcha, noisy);
        }

        /// <summary>
        /// Text captcha example
        /// </summary>
        /// <param name="length"></param>
        /// <param name="noisy"></param>
        /// <returns></returns>
        public ActionResult TextCaptcha(int length, bool noisy = true)
        {
            var random = new Random((int)DateTime.Now.Ticks);

            var captcha = "";

            //generate new question 
            int a = random.Next(10, 99);
            int b = random.Next(0, 9);
            captcha = Convert.ToBase64String(Guid.NewGuid().ToByteArray()).Substring(0, length);
            //store answer 
            Session["TextCaptcha"] = captcha;
            return RenderImage(captcha, noisy);
        }


        /// <summary>
        /// Convert captcha text into image
        /// </summary>
        /// <param name="captcha"></param>
        /// <param name="noisy"></param>
        /// <returns></returns>
        private FileContentResult RenderImage(string captcha, bool noisy = true)
        {
            var random = new Random((int)DateTime.Now.Ticks);
            //image stream 
            FileContentResult img = null;

            using (var mem = new MemoryStream())
            using (var bmp = new Bitmap(130, 30))
            using (var gfx = Graphics.FromImage((Image)bmp))
            {
                gfx.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                gfx.SmoothingMode = SmoothingMode.AntiAlias;
                gfx.FillRectangle(Brushes.White, new Rectangle(0, 0, bmp.Width, bmp.Height));

                //add noise 
                if (noisy)
                {
                    int i;
                    int r, x, y;
                    var pen = new Pen(Color.Yellow);
                    for (i = 1; i < 10; i++)
                    {
                        pen.Color = Color.FromArgb(
                        (random.Next(0, 255)),
                        (random.Next(0, 255)),
                        (random.Next(0, 255)));

                        r = random.Next(0, (130 / 3));
                        x = random.Next(0, 130);
                        y = random.Next(0, 30);

                        var j = x - r;
                        var k = y - r;
                        gfx.DrawEllipse(pen, j, k, r, r);
                    }
                }

                //add question 
                gfx.DrawString(captcha, new Font("Arial", 15), Brushes.Gray, 2, 3);

                //render as Jpeg 
                bmp.Save(mem, System.Drawing.Imaging.ImageFormat.Jpeg);
                img = this.File(mem.GetBuffer(), "image/Jpeg");
            }

            return img;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCCaptcha.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string Captcha { get; set; }
    }
}